const $ = id => document.getElementById(id);
let plan = null;
let history = [];
const apiBase = '/api';

$('generate').addEventListener('click', generatePlan);

document.querySelectorAll('.tab').forEach(btn => btn.addEventListener('click', () => {
  document.querySelectorAll('.tab').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(c => c.classList.add('hidden'));
  btn.classList.add('active');
  $(btn.dataset.tab).classList.remove('hidden');
}));

async function generatePlan() {
  const button = $('generate');
  button.disabled = true;
  $('status').textContent = '🤖 Designing your plan...';
  const payload = {
    age: $('age').value, height_cm: $('height').value, weight_kg: $('weight').value,
    gender: $('gender').value, environment: $('environment').value,
    workout_days_per_week: $('days').value, workout_duration_minutes: $('duration').value,
    main_goal: $('goal').value, target_kg: $('target').value, want_abs: $('abs').checked,
    state_location: $('state').value, vegetarian_status: $('veg').value, food_style: $('food').value
  };
  try {
    const res = await fetch(`${apiBase}/generate-comprehensive-plan`, {
      method:'POST', headers:{'Content-Type':'application/json', ...keyHeader()}, body:JSON.stringify(payload)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Server error');
    plan = data; history = [];
    renderPlan();
    $('status').textContent = '✅ Plan generated!';
  } catch (e) { $('status').textContent = `❌ ${e.message}`; }
  finally { button.disabled = false; }
}

function keyHeader(){ const key=$('apiKey').value.trim(); return key ? {'X-Gemini-API-Key':key} : {}; }

function renderPlan(){
  $('dashboard').classList.remove('hidden');
  $('summary').innerHTML = `<strong>📋 Plan Summary:</strong> ${escapeHtml(plan.user_summary || '')}`;
  renderWorkouts(); renderNutrition(); renderChat();
}

function renderWorkouts(){
  let total=0, done=0;
  const saved = JSON.parse(localStorage.getItem('fitbuddy_progress') || '{}');
  let html='<h2>Your Workout Routine</h2>';
  (plan.workout_schedule||[]).forEach((day,di)=>{
    html += `<div class="day"><h3>📅 ${escapeHtml(day.day_name)} — ${escapeHtml(day.focus)}</h3>`;
    (day.exercises||[]).forEach((ex,ei)=>{
      total++; const key=`${di}_${ei}`; const checked=!!saved[key]; if(checked)done++;
      html += `<div class="exercise"><label class="check"><input type="checkbox" data-progress="${key}" ${checked?'checked':''}> <span><b>${escapeHtml(ex.name)}</b> | ${ex.sets} × ${escapeHtml(ex.reps)}<br><small>Tip: ${escapeHtml(ex.instructions)}</small></span></label></div>`;
    }); html+='</div>';
  });
  const pct=total?Math.round(done/total*100):0;
  html += `<h3>📊 Progress: ${pct}% (${done}/${total})</h3><div class="progress"><div style="width:${pct}%"></div></div>`;
  $('workouts').innerHTML=html;
  $('workouts').querySelectorAll('[data-progress]').forEach(cb=>cb.addEventListener('change',e=>{
    const s=JSON.parse(localStorage.getItem('fitbuddy_progress')||'{}'); s[e.target.dataset.progress]=e.target.checked; localStorage.setItem('fitbuddy_progress',JSON.stringify(s)); renderWorkouts();
  }));
}

function renderNutrition(){
  $('nutrition').innerHTML='<h2>🍎 Nutrition Plan</h2>'+(plan.nutrition_plan||[]).map(m=>`<div class="meal"><b>${escapeHtml(m.meal_type)}:</b> ${escapeHtml(m.description)}</div>`).join('');
}

function renderChat(){
  $('chat').innerHTML=`<h2>💬 FitBuddy Chatbot</h2><div id="chatList" class="chat-list">${history.map(m=>`<div class="message ${m.role}">${escapeHtml(m.content)}</div>`).join('')}</div><div class="chat-row"><input id="chatInput" placeholder="Ask about form, alternatives, motivation, or diet..."/><button id="sendChat">Send</button></div>`;
  $('sendChat').addEventListener('click',sendChat); $('chatInput').addEventListener('keydown',e=>{if(e.key==='Enter')sendChat();});
}

async function sendChat(){
  const input=$('chatInput'); const message=input.value.trim(); if(!message)return;
  history.push({role:'user',content:message}); renderChat(); $('chatInput').disabled=true;
  try{ const res=await fetch(`${apiBase}/chat`,{method:'POST',headers:{'Content-Type':'application/json',...keyHeader()},body:JSON.stringify({message,history:history.slice(0,-1),plan_summary:plan?.user_summary||''})}); const data=await res.json(); if(!res.ok)throw new Error(data.error||'Server error'); history.push({role:'assistant',content:data.response}); }
  catch(e){history.push({role:'assistant',content:`Error: ${e.message}`});}
  renderChat();
}

function escapeHtml(value){return String(value??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
