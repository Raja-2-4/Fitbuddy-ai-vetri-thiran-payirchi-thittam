const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

loadEnv(path.join(__dirname, '..', '.env'));

const PORT = Number(process.env.PORT || 5000);
const MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const PUBLIC_DIR = path.join(__dirname, 'public');

function loadEnv(file) {
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const i = trimmed.indexOf('=');
    if (i < 1) continue;
    const key = trimmed.slice(0, i).trim();
    let value = trimmed.slice(i + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
    if (!process.env[key]) process.env[key] = value;
  }
}

function json(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, X-Gemini-API-Key',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 1_000_000) req.destroy(new Error('Request too large'));
    });
    req.on('end', () => {
      try { resolve(body ? JSON.parse(body) : {}); }
      catch { reject(new Error('Invalid JSON body')); }
    });
    req.on('error', reject);
  });
}

function intValue(value, fallback, min, max) {
  const n = Number.parseInt(value, 10);
  return Number.isFinite(n) ? Math.max(min, Math.min(max, n)) : fallback;
}
function floatValue(value, fallback, min, max) {
  const n = Number.parseFloat(value);
  return Number.isFinite(n) ? Math.max(min, Math.min(max, n)) : fallback;
}
function apiKey(req) {
  return req.headers['x-gemini-api-key'] || process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY;
}

const planSchema = {
  type: 'OBJECT',
  properties: {
    user_summary: { type: 'STRING', description: 'Summary of user metrics, goals and targets' },
    workout_schedule: {
      type: 'ARRAY', items: {
        type: 'OBJECT', properties: {
          day_name: { type: 'STRING' },
          focus: { type: 'STRING' },
          exercises: { type: 'ARRAY', items: {
            type: 'OBJECT', properties: {
              name: { type: 'STRING' }, sets: { type: 'INTEGER' }, reps: { type: 'STRING' }, instructions: { type: 'STRING' }
            }, required: ['name', 'sets', 'reps', 'instructions']
          }}
        }, required: ['day_name', 'focus', 'exercises']
      }
    },
    nutrition_plan: { type: 'ARRAY', items: {
      type: 'OBJECT', properties: { meal_type: { type: 'STRING' }, description: { type: 'STRING' } },
      required: ['meal_type', 'description']
    }}
  }, required: ['user_summary', 'workout_schedule', 'nutrition_plan']
};

async function geminiGenerate(req, body) {
  const key = apiKey(req);
  if (!key) throw new Error('Gemini API key is missing. Add GEMINI_API_KEY to .env or enter it in the app.');
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${encodeURIComponent(key)}`;
  const response = await fetch(endpoint, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error?.message || `Gemini API error (${response.status})`);
  return data;
}

async function generatePlan(req, data) {
  const age = intValue(data.age, 19, 10, 100);
  const gender = String(data.gender || 'Male').slice(0, 30);
  const environment = String(data.environment || 'gym').slice(0, 30);
  const days = intValue(data.workout_days_per_week, 5, 1, 7);
  const duration = intValue(data.workout_duration_minutes, 45, 15, 120);
  const goal = String(data.main_goal || 'weight_loss').replaceAll('_', ' ');
  const targetKg = floatValue(data.target_kg, 5, 0.5, 50);
  const wantAbs = Boolean(data.want_abs);
  const state = String(data.state_location || 'Tamil Nadu').slice(0, 60);
  const vegStatus = String(data.vegetarian_status || 'Vegetarian').slice(0, 30);
  const foodStyle = String(data.food_style || 'Home food').slice(0, 30);
  const heightCm = floatValue(data.height_cm, 165, 100, 230);
  const weightKg = floatValue(data.weight_kg, 60, 25, 250);

  const prompt = `You are FitBuddy, an expert AI fitness coach. Craft a customized routine.\n- Age/Gender: ${age} yrs, ${gender}\n- Height/Weight: ${heightCm} cm, ${weightKg} kg\n- Workout Environment: ${environment}\n- Schedule: ${days} workout days per week, with remaining days as rest/recovery\n- Session duration: ${duration} minutes\n- Primary Goal: ${goal} (target change: ${targetKg} kg)\n- Abs focus: ${wantAbs ? 'Yes, include core/abs work' : 'No, standard routine'}\n- Location: ${state}, India\n- Dietary Type: ${vegStatus}\n- Food Style: ${foodStyle}\n\nProvide: 1. A short summary acknowledging the goals and a safe, realistic pace. Do not prescribe extreme dieting. 2. EXACTLY ${days} workout days, each fitting about ${duration} minutes and using only ${environment} equipment. 3. A full day of meals (Breakfast, Lunch, Snack, Dinner) using local ${state} ingredients that respect the ${vegStatus} preference and ${foodStyle} style.`;

  const dataOut = await geminiGenerate(req, {
    contents: [{ role: 'user', parts: [{ text: prompt }] }],
    generationConfig: { responseMimeType: 'application/json', responseSchema: planSchema, temperature: 0.7 }
  });
  const text = dataOut.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('') || '';
  if (!text) throw new Error('Gemini returned an empty plan.');
  return JSON.parse(text);
}

async function chat(req, data) {
  const message = String(data.message || '').trim();
  if (!message) throw new Error('Message is required');
  const history = Array.isArray(data.history) ? data.history : [];
  const planSummary = String(data.plan_summary || '').slice(0, 1500);
  let systemInstruction = "You are FitBuddy's AI fitness chatbot. Help users step-by-step with gym/home workouts, exercise form, motivation, and local healthy food options. Be concise, encouraging, and clear. Do not encourage extreme dieting or unsafe exercise. For injuries or medical conditions, suggest talking to a qualified healthcare professional.";
  if (planSummary) systemInstruction += `\nUser's current plan summary: ${planSummary}`;
  const contents = history.slice(-20).map(turn => ({ role: turn.role === 'assistant' ? 'model' : 'user', parts: [{ text: String(turn.content || '') }] })).filter(x => x.parts[0].text);
  contents.push({ role: 'user', parts: [{ text: message }] });
  const dataOut = await geminiGenerate(req, { systemInstruction: { parts: [{ text: systemInstruction }] }, contents, generationConfig: { temperature: 0.7 } });
  return dataOut.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('') || "I couldn't generate a reply.";
}

function contentType(file) {
  const ext = path.extname(file).toLowerCase();
  return ({'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml'}[ext] || 'application/octet-stream');
}
function serveStatic(req, res, pathname) {
  let file = pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, '');
  const full = path.resolve(PUBLIC_DIR, file);
  if (!full.startsWith(path.resolve(PUBLIC_DIR))) return json(res, 403, { error: 'Forbidden' });
  if (!fs.existsSync(full) || fs.statSync(full).isDirectory()) return json(res, 404, { error: 'Not found' });
  res.writeHead(200, {'Content-Type': contentType(full), 'Cache-Control':'no-cache'});
  fs.createReadStream(full).pipe(res);
}

const server = http.createServer(async (req, res) => {
  const parsed = url.parse(req.url, true);
  if (req.method === 'OPTIONS') return json(res, 204, {});
  try {
    if (req.method === 'GET' && parsed.pathname === '/api/health') return json(res, 200, { status: 'ok' });
    if (req.method === 'POST' && parsed.pathname === '/api/generate-comprehensive-plan') return json(res, 200, await generatePlan(req, await readBody(req)));
    if (req.method === 'POST' && parsed.pathname === '/api/chat') return json(res, 200, { response: await chat(req, await readBody(req)) });
    if (req.method === 'GET') return serveStatic(req, res, parsed.pathname);
    return json(res, 404, { error: 'Not found' });
  } catch (error) {
    console.error(error);
    return json(res, 500, { error: error.message || 'Server error' });
  }
});

server.listen(PORT, '0.0.0.0', () => console.log(`FitBuddy running at http://localhost:${PORT}`));
